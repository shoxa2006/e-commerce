<?php
session_start();
require_once 'db.php';
include 'header.php';

$error = '';
// Initialize variables so they aren't undefined on first load
$name = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Capture the input values so we can put them back in the form if it fails
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $pass = $_POST['password'];
    $confirm_pass = $_POST['confirm_password'];

    // 2. Validation
    if ($pass !== $confirm_pass) {
        echo "<script>document.addEventListener('DOMContentLoaded',()=>modal.show('Error','Passwords do not match!','error'));</script>";
    } else {
        // Check if email exists
        $stmt = $pdo->prepare("SELECT user_id FROM users WHERE email = ?");
        $stmt->execute([$email]);

        if ($stmt->fetch()) {
            echo "<script>document.addEventListener('DOMContentLoaded',()=>modal.show('Error','Email already registered','error'));</script>";
        } else {
            // Hash password and insert
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (full_name, email, password_hash) VALUES (?, ?, ?)");

            if ($stmt->execute([$name, $email, $hash])) {
                // Auto Login
                $_SESSION['user_id'] = $pdo->lastInsertId();
                $_SESSION['role'] = 'customer';
                $_SESSION['name'] = $name;

                echo "<script>window.location.href='index.php';</script>";
                exit;
            } else {
                echo "<script>document.addEventListener('DOMContentLoaded',()=>modal.show('Error','Registration failed','error'));</script>";
            }
        }
    }
}
?>

    <div class="container" style="max-width:450px; margin:80px auto;">
        <div style="background:white; padding:40px; border-radius:16px; box-shadow:var(--shadow); border:1px solid var(--border);">

            <div class="text-center" style="margin-bottom:30px;">
                <h2 style="font-weight:700; margin-bottom:10px;">Create Account</h2>
                <p style="color:var(--text-muted); font-size:0.9rem;">Join us to access exclusive deals and features.</p>
            </div>

            <form method="POST">
                <label style="font-weight:600; font-size:0.9rem; display:block; margin-bottom:5px;">Full Name</label>
                <input type="text" name="name" class="form-control" required placeholder="e.g. John Doe" value="<?= htmlspecialchars($name) ?>">

                <label style="font-weight:600; font-size:0.9rem; display:block; margin-bottom:5px;">Email Address</label>
                <input type="email" name="email" class="form-control" required placeholder="name@company.com" value="<?= htmlspecialchars($email) ?>">

                <label style="font-weight:600; font-size:0.9rem; display:block; margin-bottom:5px;">Password</label>
                <input type="password" name="password" class="form-control" required placeholder="Create a strong password">

                <label style="font-weight:600; font-size:0.9rem; display:block; margin-bottom:5px;">Confirm Password</label>
                <input type="password" name="confirm_password" class="form-control" required placeholder="Retype your password">

                <button type="submit" class="btn btn-primary w-100" style="margin-top:10px; padding:12px;">Sign Up</button>
            </form>

            <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #f1f5f9; text-align: center;">
                <p style="color:var(--text-muted); font-size:0.9rem; margin-bottom:15px;">Already have an account?</p>
                <a href="login.php" class="btn btn-secondary w-100">Sign In</a>
            </div>

        </div>
    </div>

<?php include 'footer.php'; ?>