<?php
session_start();
require_once '../db.php';
header('Content-Type: application/json');

// 1. Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];
$action  = $_POST['action'] ?? '';

try {
    // ==========================================
    // ACTION: ADD TO CART
    // ==========================================
    if ($action === 'add') {
        $product_id = $_POST['product_id'];
        $quantity   = (int)$_POST['quantity'];

        // Check if item already exists in cart
        $stmt = $pdo->prepare("SELECT cart_item_id, quantity FROM cart_items WHERE user_id = ? AND product_id = ?");
        $stmt->execute([$user_id, $product_id]);
        $existing = $stmt->fetch();

        if ($existing) {
            // Update quantity
            $newQty = $existing['quantity'] + $quantity;
            $update = $pdo->prepare("UPDATE cart_items SET quantity = ? WHERE cart_item_id = ?");
            $update->execute([$newQty, $existing['cart_item_id']]);
        } else {
            // Insert new item
            $insert = $pdo->prepare("INSERT INTO cart_items (user_id, product_id, quantity) VALUES (?, ?, ?)");
            $insert->execute([$user_id, $product_id, $quantity]);
        }
        echo json_encode(['success' => true]);
    }

    // ==========================================
    // ACTION: REMOVE FROM CART (The Missing Part)
    // ==========================================
    elseif ($action === 'remove') {
        $cart_item_id = $_POST['cart_item_id'];

        // Secure Delete: Ensure the item belongs to the logged-in user
        $stmt = $pdo->prepare("DELETE FROM cart_items WHERE cart_item_id = ? AND user_id = ?");
        $result = $stmt->execute([$cart_item_id, $user_id]);

        if ($result && $stmt->rowCount() > 0) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Item not found or could not be deleted.']);
        }
    }

    // ==========================================
    // ACTION: CHECKOUT
    // ==========================================
    elseif ($action === 'checkout') {
        $pdo->beginTransaction();

        // 1. Get Cart Items
        $stmt = $pdo->prepare("SELECT ci.*, p.price FROM cart_items ci JOIN products p ON ci.product_id = p.product_id WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $items = $stmt->fetchAll();

        if (!$items) {
            throw new Exception("Cart is empty");
        }

        // 2. Calculate Total
        $total = 0;
        foreach ($items as $item) {
            $total += $item['price'] * $item['quantity'];
        }

        // 3. Create Order
        $orderStmt = $pdo->prepare("INSERT INTO orders (user_id, total) VALUES (?, ?) RETURNING order_id");
        $orderStmt->execute([$user_id, $total]);
        $order_id = $orderStmt->fetchColumn();

        // 4. Move Items to Order Details
        $detailStmt = $pdo->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
        foreach ($items as $item) {
            $detailStmt->execute([$order_id, $item['product_id'], $item['quantity'], $item['price']]);
        }

        // 5. Clear Cart
        $pdo->prepare("DELETE FROM cart_items WHERE user_id = ?")->execute([$user_id]);

        $pdo->commit();
        echo json_encode(['success' => true]);
    }

    else {
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
    }

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>