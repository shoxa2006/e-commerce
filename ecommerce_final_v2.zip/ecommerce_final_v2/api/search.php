<?php
require_once '../db.php';
header('Content-Type: application/json');

// 1. Get Parameters
$q    = $_GET['q'] ?? '';
$cat  = $_GET['category'] ?? '';
$min  = $_GET['min'] ?? '';
$max  = $_GET['max'] ?? '';
$sort = $_GET['sort'] ?? 'newest';

// 2. Build Query
$sql = "SELECT p.*, c.name as category_name 
        FROM products p 
        LEFT JOIN categories c ON p.category_id = c.category_id 
        WHERE 1=1";

$params = [];

// Search Text
if (!empty($q)) {
    $sql .= " AND (p.name ILIKE ? OR p.description ILIKE ?)";
    $params[] = "%$q%";
    $params[] = "%$q%";
}

// Category
if (!empty($cat)) {
    $sql .= " AND p.category_id = ?";
    $params[] = $cat;
}

// Price Range (Strict Numeric Check)
if (is_numeric($min)) {
    $sql .= " AND p.price >= ?";
    $params[] = $min;
}

if (is_numeric($max)) {
    $sql .= " AND p.price <= ?";
    $params[] = $max;
}

// 3. Sorting Logic
switch ($sort) {
    case 'price_asc':
        $sql .= " ORDER BY p.price ASC";
        break;
    case 'price_desc':
        $sql .= " ORDER BY p.price DESC";
        break;
    case 'oldest':
        $sql .= " ORDER BY p.created_at ASC";
        break;
    case 'newest':
    default:
        $sql .= " ORDER BY p.created_at DESC";
        break;
}

// 4. Execute
try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Ensure we always output valid JSON
    echo json_encode($results);
} catch (PDOException $e) {
    // If SQL fails, return empty array to prevent JS crash
    echo json_encode([]);
}
?>