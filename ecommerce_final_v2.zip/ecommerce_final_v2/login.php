<?php
session_start();
require_once 'db.php';
include 'header.php';

if($_POST){
    $email = $_POST['email'];
    $pass = $_POST['password'];

    $s = $pdo->prepare("SELECT * FROM users WHERE email=?");
    $s->execute([$email]);
    $u = $s->fetch();

    if($u && password_verify($pass, $u['password_hash'])){
        $_SESSION['user_id'] = $u['user_id'];
        $_SESSION['role'] = $u['role'];

        // Redirect based on role
        if($u['role'] === 'admin') {
            header("Location: admin/index.php");
        } else {
            header("Location: index.php");
        }
        exit;
    } else {
        echo "<script>document.addEventListener('DOMContentLoaded',()=>modal.show('Error','Invalid email or password','error'));</script>";
    }
}
?>

    <div class="container" style="max-width:400px; margin:80px auto;">
        <div style="background:white; padding:40px; border-radius:16px; box-shadow:var(--shadow); border:1px solid var(--border);">

            <div class="text-center" style="margin-bottom:30px;">
                <h2 style="font-weight:700; margin-bottom:10px;">Welcome Back</h2>
                <p style="color:var(--text-muted); font-size:0.9rem;">Please enter your details to sign in.</p>
            </div>

            <form method="post">
                <label style="font-weight:600; font-size:0.9rem; display:block; margin-bottom:5px;">Email Address</label>
                <input name="email" type="email" class="form-control" required placeholder="name@company.com">

                <label style="font-weight:600; font-size:0.9rem; display:block; margin-bottom:5px;">Password</label>
                <input name="password" type="password" class="form-control" required placeholder="••••••••">

                <button class="btn btn-primary w-100" style="margin-top:10px; padding:12px;">Sign In</button>
            </form>

            <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #f1f5f9; text-align: center;">
                <p style="color:var(--text-muted); font-size:0.9rem; margin-bottom:15px;">Don't have an account yet?</p>
                <a href="register.php" class="btn btn-secondary w-100">Create Account</a>
            </div>

        </div>
    </div>

<?php include 'footer.php'; ?>