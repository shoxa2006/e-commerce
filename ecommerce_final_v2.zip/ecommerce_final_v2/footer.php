<?php
// Ensure DB connection if not already present
require_once __DIR__ . '/db.php';

// Fetch Categories for the footer links
$footerCats = $pdo->query("SELECT * FROM categories ORDER BY name LIMIT 5")->fetchAll();
?>

<footer class="modern-footer">
    <div class="container">
        <div class="footer-content">

            <div>
                <div style="font-size: 1.4rem; font-weight: 700; color: white; margin-bottom: 10px;">
                    <i class="fas fa-bolt" style="color: #0D6EFD;"></i> Lumina
                </div>
                <p style="line-height: 1.5; opacity: 0.8;">
                    Elevating your lifestyle with premium electronics and minimalist fashion. Quality meets modern design.
                </p>
                <div class="social-row">
                    <a href="#" class="social-icon"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="social-icon"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="social-icon"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#" class="social-icon"><i class="fab fa-telegram"></i></a>
                </div>
            </div>

            <div>
                <div class="footer-heading">Shop</div>
                <ul class="footer-nav">
                    <li><a href="products.php">All Products</a></li>
                    <?php foreach($footerCats as $cat): ?>
                        <li><a href="products.php?category_id=<?= $cat['category_id'] ?>"><?= htmlspecialchars($cat['name']) ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div>
                <div class="footer-heading">Company</div>
                <ul class="footer-nav">
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Contact Support</a></li>
                    <li><a href="#">Shipping Policy</a></li>
                    <li><a href="#">Returns & Refunds</a></li>
                    <li><a href="admin/index.php">Admin Login</a></li>
                </ul>
            </div>

            <div>
                <div class="footer-heading">Stay Updated</div>
                <p style="margin-bottom: 10px; opacity: 0.8;">Get the latest deals and new arrivals sent to your inbox.</p>
                <form action="#" method="POST" onsubmit="event.preventDefault(); alert('Subscribed!');">
                    <div class="footer-input-group">
                        <input type="email" class="footer-input" placeholder="Your email address" required>
                        <button type="submit" class="footer-btn"><i class="fas fa-paper-plane"></i></button>
                    </div>
                </form>
            </div>
        </div>

        <div class="footer-bottom">
            <div>&copy; <?php echo date('Y'); ?> Lumina Inc. All rights reserved.</div>
            <div style="display: flex; gap: 20px;">
                <a href="#">Privacy</a>
                <a href="#">Terms</a>
                <a href="#">Sitemap</a>
            </div>
        </div>
    </div>
</footer>

<script src="js/app.js"></script>
<script src="js/slider.js"></script>
</body>
</html>