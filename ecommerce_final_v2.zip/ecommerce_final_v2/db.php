<?php
$host = 'dpg-d4ob4jq4d50c738ok50g-a';
$db   = 'ecommerce_db_60h9';
$user = 'shoxrux';
$pass = 'hsKoIj58SJJ2A8ns4xB6MQSQcSTR554l';
$port = "5432";

$dsn = "pgsql:host=$host;port=$port;dbname=$db;";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}
?>