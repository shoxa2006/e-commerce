<?php
session_start();
require_once '../db.php';

// 1. Security Check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// 2. Fetch ALL Products (Joined with Categories)
// We order by product_id DESC so newest products appear first
$sql = "SELECT p.*, c.name as cat_name 
        FROM products p 
        LEFT JOIN categories c ON p.category_id = c.category_id 
        ORDER BY p.product_id DESC";
$products = $pdo->query($sql)->fetchAll();
include 'header.php';
?>
<div class="container" style="margin-top:40px;">

    <div class="admin-header">
        <h2>All Products (<?= count($products) ?>)</h2>
        <a href="add_product.php" class="btn btn-primary btn-sm">
            <i class="fas fa-plus"></i> Add New Product
        </a>
    </div>

    <div style="background:white; border-radius:12px; border:1px solid #dee2e6; overflow:hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); margin-bottom: 50px;">
        <table class="admin-table" style="margin:0; border:none; shadow:none;">
            <thead>
            <tr>
                <th>ID</th>
                <th>Image</th>
                <th>Name</th>
                <th>Category</th>
                <th>Price</th>
                <th style="text-align:right;">Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php if (empty($products)): ?>
                <tr>
                    <td colspan="6" style="text-align:center; padding:40px; color:#6c757d;">
                        No products found. <a href="add_product.php" style="color:var(--primary);">Add one now</a>.
                    </td>
                </tr>
            <?php else: ?>
                <?php foreach($products as $p): ?>
                    <tr>
                        <td style="color:#6c757d;">#<?= $p['product_id'] ?></td>
                        <td>
                            <img src="<?= htmlspecialchars($p['image_url']) ?>" style="width:40px; height:40px; border-radius:6px; object-fit:cover; border:1px solid #eee;">
                        </td>
                        <td style="font-weight:600;"><?= htmlspecialchars($p['name']) ?></td>
                        <td>
                            <?php if($p['cat_name']): ?>
                                <span class="badge badge-secondary"><?= htmlspecialchars($p['cat_name']) ?></span>
                            <?php else: ?>
                                <span style="color:#999; font-size:0.85rem;">Uncategorized</span>
                            <?php endif; ?>
                        </td>
                        <td style="font-weight:bold; color:#212529;">$<?= number_format($p['price'], 2) ?></td>
                        <td class="admin-actions" style="justify-content:flex-end; padding: 21px;">
                            <a href="edit_product.php?id=<?= $p['product_id'] ?>" class="action-icon edit-icon" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <a href="#" onclick="confirmDelete('delete_product.php?id=<?= $p['product_id'] ?>')" class="action-icon delete-icon" title="Delete">
                                <i class="fas fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>


<script src="../js/app.js"></script>
<script>
    // Helper for delete confirmation
    function confirmDelete(url) {
        if(confirm('Are you sure you want to delete this product? This cannot be undone.')) {
            window.location.href = url;
        }
    }
</script>

<?php
// 2. Include Footer
include 'footer.php';
?>