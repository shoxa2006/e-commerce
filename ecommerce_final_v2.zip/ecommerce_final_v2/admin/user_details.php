<?php session_start(); require_once '../db.php'; if ($_SESSION['role'] !== 'admin') { header("Location: ../login.php"); exit; }
$id = $_GET['id']; $u = $pdo->prepare("SELECT * FROM users WHERE user_id = ?"); $u->execute([$id]); $user = $u->fetch();
$ord = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC"); $ord->execute([$id]); $orders = $ord->fetchAll();
$total = 0; foreach($orders as $o) $total += $o['total'];
$cart = $pdo->prepare("SELECT ci.quantity, p.name, p.image_url FROM cart_items ci JOIN products p ON ci.product_id = p.product_id WHERE ci.user_id = ?"); $cart->execute([$id]); $items = $cart->fetchAll();

include 'header.php';
?>
<div class="container" style="margin-top:40px;">

    <div class="admin-header"><h2><?= htmlspecialchars($user['full_name']) ?></h2><a href="users.php" class="btn btn-secondary btn-sm">Back</a></div>
    <div class="stat-grid"><div class="stat-card"><div class="stat-title">Orders</div><div class="stat-value"><?= count($orders) ?></div></div><div class="stat-card"><div class="stat-title">Spent</div><div class="stat-value">$<?= number_format($total, 2) ?></div></div></div>
    <div style="display:grid; grid-template-columns: 2fr 1fr; gap:20px; margin-bottom: 50px;">
        <div><div class="detail-card"><div class="detail-header">Order History</div><div class="detail-body"><table class="admin-table"><thead><tr><th>ID</th><th>Date</th><th>Total</th></tr></thead><tbody><?php foreach($orders as $o): ?><tr><td>#<?= $o['order_id'] ?></td><td><?= date('M d, Y', strtotime($o['created_at'])) ?></td><td>$<?= $o['total'] ?></td></tr><?php endforeach; ?></tbody></table></div></div></div>
        <div><div class="detail-card"><div class="detail-header">Cart</div><div class="detail-body"><ul><?php foreach($items as $i): ?><li><?= $i['quantity'] ?>x <?= $i['name'] ?></li><?php endforeach; ?></ul></div></div></div>
    </div>
</div>
<script src="../js/app.js"></script>
<script>
    const current = location.pathname.split('/').pop();
    document.querySelectorAll('.nav-links a').forEach(a => { if(a.getAttribute('href') === current) { a.style.color = '#fff'; a.style.fontWeight = 'bold'; }});
</script>
<?php
// 2. Include Footer
include 'footer.php';
?>