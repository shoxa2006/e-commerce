<?php session_start(); require_once '../db.php'; if($_SESSION['role']!='admin') die; if($_POST){ $pdo->prepare("INSERT INTO categories (name) VALUES (?)")->execute([$_POST['name']]); header("Location: categories.php"); }
include 'header.php';
?>
<div class="container" style="margin-top:40px;">

<div style="max-width:500px; margin:0 auto;"><div style="margin-bottom:15px;">
        <a href="categories.php" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left"></i> Back to Categories</a>
    </div><div class="stat-card"><h2>Add Category</h2><form method="post"><input name="name" class="form-control" placeholder="Name"><button class="btn btn-primary">Add</button></form></div></div></div>

<script src="../js/app.js">
</script>
<script>
const current = location.pathname.split('/').pop();
document.querySelectorAll('.nav-links a').forEach(a => { if(a.getAttribute('href') === current) { a.style.color = '#fff'; a.style.fontWeight = 'bold'; }});
</script>

<?php
// 2. Include Footer
include 'footer.php';
?>