<?php
// Ensure session is started if not already
if (session_status() === PHP_SESSION_NONE) session_start();

// Security Check (Optional but recommended here or in individual pages)
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    // If included in a subdirectory, adjust path
    header("Location: ../login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Lumina</title>

    <!-- Link to the main style.css -->
    <link rel="stylesheet" href="../css/style.css">

    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Chart.js (Only used in dashboard, but harmless to load everywhere) -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

<!-- Global Modal (For Success/Error/Delete Confirmations) -->
<div class="modal-overlay" id="globalModal">
    <div class="modal-box">
        <div class="modal-icon"><i class="fas fa-check-circle"></i></div>
        <h3 class="modal-title">Success</h3>
        <p class="modal-msg">Operation completed.</p>
        <!-- Buttons will be injected here by JS -->
    </div>
</div>

<!-- Admin Navbar -->
<nav class="navbar" style="background:#1e293b; border:none;">
    <div class="container nav-flex">
        <span class="brand" style="color:white; background:none;">Admin Panel</span>

        <?php
        // Get current file name for active state
        $current_page = basename($_SERVER['PHP_SELF']);
        ?>

        <div class="nav-links">
            <a href="index.php" style="<?= ($current_page == 'index.php') ? 'color:#fff; font-weight:bold;' : 'color:#cbd5e1;' ?>">Dashboard</a>
            <a href="products.php" style="<?= ($current_page == 'products.php' || $current_page == 'add_product.php' || $current_page == 'edit_product.php') ? 'color:#fff; font-weight:bold;' : 'color:#cbd5e1;' ?>">Products</a>
            <a href="users.php" style="<?= ($current_page == 'users.php' || $current_page == 'user_details.php' || $current_page == 'edit_user.php') ? 'color:#fff; font-weight:bold;' : 'color:#cbd5e1;' ?>">Users</a>
            <a href="categories.php" style="<?= ($current_page == 'categories.php' || $current_page == 'add_category.php' || $current_page == 'edit_category.php') ? 'color:#fff; font-weight:bold;' : 'color:#cbd5e1;' ?>">Categories</a>

            <a href="../index.php" style="color:#60a5fa; font-size:0.9rem;">View Shop <i class="fas fa-external-link-alt"></i></a>
            <a href="../logout.php" style="color:#ef4444;">Logout</a>
        </div>
    </div>
</nav>

<!-- Main Container Start -->
<div class="container" style="margin-top:40px; flex: 1;">