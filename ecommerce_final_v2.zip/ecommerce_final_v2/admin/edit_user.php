<?php session_start(); require_once '../db.php'; if ($_SESSION['role'] !== 'admin') { header("Location: ../login.php"); exit; }
$id = $_GET['id'] ?? 0; $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?"); $stmt->execute([$id]); $user = $stmt->fetch();
$success = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['full_name']); $email = trim($_POST['email']); $role = $_POST['role']; $new_pass = trim($_POST['password']);
    $sql = "UPDATE users SET full_name = ?, email = ?, role = ? WHERE user_id = ?"; $params = [$name, $email, $role, $id];
    if (!empty($new_pass)) { $sql = "UPDATE users SET full_name = ?, email = ?, role = ?, password_hash = ? WHERE user_id = ?"; $hash = password_hash($new_pass, PASSWORD_DEFAULT); $params = [$name, $email, $role, $hash, $id]; }
    if($pdo->prepare($sql)->execute($params)) { $success = true; $stmt->execute([$id]); $user = $stmt->fetch(); }
}
include 'header.php';
?>
<div class="container" style="margin-top:40px;">

    <div style="max-width:600px; margin:0 auto;"><div class="admin-header"><h2>Edit User</h2><a href="users.php" class="btn btn-secondary btn-sm">Back</a></div>
    <div class="stat-card"><form method="POST"><label>Full Name</label><input name="full_name" class="form-control" value="<?= htmlspecialchars($user['full_name']) ?>" required>
    <label>Email</label><input type="email" name="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" required>
    <label>Role</label><select name="role" class="form-control"><option value="customer" <?= $user['role']=='customer'?'selected':''?>>Customer</option><option value="admin" <?= $user['role']=='admin'?'selected':''?>>Admin</option></select>
    <hr><label>Reset Password (Optional)</label><input name="password" class="form-control" placeholder="New password..."><button class="btn btn-primary w-100">Save</button></form></div></div>
    <?php if($success): ?><script>document.addEventListener('DOMContentLoaded', () => { modal.show('Updated!', 'User updated.', 'success', 'users.php'); });</script><?php endif; ?>
</div>
<script src="../js/app.js"></script>
<script>
const current = location.pathname.split('/').pop();
document.querySelectorAll('.nav-links a').forEach(a => { if(a.getAttribute('href') === current) { a.style.color = '#fff'; a.style.fontWeight = 'bold'; }});
</script>
<?php
// 2. Include Footer
include 'footer.php';
?>