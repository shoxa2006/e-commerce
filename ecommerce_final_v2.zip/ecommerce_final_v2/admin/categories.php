<?php session_start(); require_once '../db.php'; if ($_SESSION['role'] !== 'admin') die('Access Denied');
$cats = $pdo->query("SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id = c.category_id) as p_count FROM categories c ORDER BY category_id ASC")->fetchAll();
include 'header.php';
?>
<div class="container" style="margin-top:40px;">

<div class="admin-header"><h2>Categories</h2><a href="add_category.php" class="btn btn-primary btn-sm">Add Category</a></div>
<table class="admin-table"><thead><tr><th>Name</th><th>Count</th><th>Actions</th></tr></thead><tbody><?php foreach($cats as $cat): ?><tr><td><?= htmlspecialchars($cat['name']) ?></td><td><?= $cat['p_count'] ?> products</td>
<td class="admin-actions"><a href="edit_category.php?id=<?= $cat['category_id'] ?>" class="action-icon edit-icon"><i class="fas fa-edit"></i></a><a href="#" onclick="confirmDelete('delete_category.php?id=<?=$cat['category_id']?>')" class="action-icon delete-icon"><i class="fas fa-trash"></i></a></td></tr><?php endforeach; ?></tbody></table>
</div>
<script src="../js/app.js"></script>
<script>
    const current = location.pathname.split('/').pop();
    document.querySelectorAll('.nav-links a').forEach(a => { if(a.getAttribute('href') === current) { a.style.color = '#fff'; a.style.fontWeight = 'bold'; }});
</script>
<?php
// 2. Include Footer
include 'footer.php';
?>