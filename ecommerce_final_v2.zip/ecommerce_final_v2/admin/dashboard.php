<?php
session_start();
require_once '../db.php';

// 1. Security Check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// 2. Fetch Real Key Metrics from DB
$prod_count = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
$user_count = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$order_count = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$revenue    = $pdo->query("SELECT SUM(total) FROM orders")->fetchColumn();
$revenue    = $revenue ? $revenue : 0; // Handle null if no orders
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard - Lumina Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        /* Dashboard Specific Styles */
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
            border: 1px solid #e2e8f0;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
        }
        .bg-blue { background: #e0f2fe; color: #0284c7; }
        .bg-green { background: #dcfce7; color: #16a34a; }
        .bg-purple { background: #f3e8ff; color: #9333ea; }
        .bg-orange { background: #ffedd5; color: #ea580c; }

        .charts-section {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }
        .chart-box {
            background: white;
            padding: 25px;
            border-radius: 12px;
            border: 1px solid #e2e8f0;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
        }
        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .chart-title { font-weight: 700; color: #1e293b; }
    </style>
</head>
<body style="background:#f8fafc;">

<nav class="navbar" style="background:#1e293b; border:none;">
    <div class="container nav-flex">
        <span class="brand" style="color:white; background:none;">Admin Panel</span>
        <div class="nav-links">
            <a href="index.php" style="color:#fff; font-weight:bold;">Dashboard</a>
            <a href="products.php" style="color:#cbd5e1;">Products</a>
            <a href="users.php" style="color:#cbd5e1;">Users</a>
            <a href="categories.php" style="color:#cbd5e1;">Categories</a>
            <a href="../index.php" style="color:#60a5fa; font-size:0.9rem;">View Shop <i class="fas fa-external-link-alt"></i></a>
            <a href="../logout.php" style="color:#ef4444;">Logout</a>
        </div>
    </div>
</nav>

<div class="container" style="margin-top:40px;">

    <h2 style="margin-bottom:20px;">Overview</h2>
    <div class="dashboard-grid">
        <div class="stat-card">
            <div>
                <p style="color:#64748b; font-size:0.9rem; font-weight:600;">Total Revenue</p>
                <h2 style="font-size:2rem; font-weight:700; margin:5px 0;">$<?= number_format($revenue, 2) ?></h2>
                <span class="badge bg-green" style="font-size:0.75rem;">+12.5% this month</span>
            </div>
            <div class="stat-icon bg-green"><i class="fas fa-dollar-sign"></i></div>
        </div>

        <div class="stat-card">
            <div>
                <p style="color:#64748b; font-size:0.9rem; font-weight:600;">Total Orders</p>
                <h2 style="font-size:2rem; font-weight:700; margin:5px 0;"><?= $order_count ?></h2>
                <span class="badge bg-blue" style="font-size:0.75rem;">New orders today</span>
            </div>
            <div class="stat-icon bg-blue"><i class="fas fa-shopping-bag"></i></div>
        </div>

        <div class="stat-card">
            <div>
                <p style="color:#64748b; font-size:0.9rem; font-weight:600;">Active Users</p>
                <h2 style="font-size:2rem; font-weight:700; margin:5px 0;"><?= $user_count ?></h2>
                <span class="badge bg-purple" style="font-size:0.75rem;">Growing community</span>
            </div>
            <div class="stat-icon bg-purple"><i class="fas fa-users"></i></div>
        </div>

        <div class="stat-card">
            <div>
                <p style="color:#64748b; font-size:0.9rem; font-weight:600;">Total Products</p>
                <h2 style="font-size:2rem; font-weight:700; margin:5px 0;"><?= $prod_count ?></h2>
                <span class="badge bg-orange" style="font-size:0.75rem;">Inventory Status</span>
            </div>
            <div class="stat-icon bg-orange"><i class="fas fa-box"></i></div>
        </div>
    </div>

    <h2 style="margin-bottom:20px;">Analytics</h2>
    <div class="charts-section">

        <div class="chart-box">
            <div class="chart-header">
                <span class="chart-title">Revenue & Expenses (Yearly)</span>
                <button class="btn btn-secondary btn-sm"><i class="fas fa-download"></i></button>
            </div>
            <canvas id="revenueChart"></canvas>
        </div>

        <div class="chart-box">
            <div class="chart-header">
                <span class="chart-title">Site Traffic (Weekly)</span>
            </div>
            <canvas id="trafficChart"></canvas>
        </div>

        <div class="chart-box">
            <div class="chart-header">
                <span class="chart-title">Device Usage</span>
            </div>
            <div style="height:300px; display:flex; justify-content:center;">
                <canvas id="deviceChart"></canvas>
            </div>
        </div>

        <div class="chart-box">
            <div class="chart-header">
                <span class="chart-title">Sales by Category</span>
            </div>
            <div style="height:300px; display:flex; justify-content:center;">
                <canvas id="categoryChart"></canvas>
            </div>
        </div>

        <div class="chart-box">
            <div class="chart-header">
                <span class="chart-title">New User Signups</span>
            </div>
            <canvas id="userGrowthChart"></canvas>
        </div>

        <div class="chart-box">
            <div class="chart-header">
                <span class="chart-title">Order Fulfillment Status</span>
            </div>
            <canvas id="orderStatusChart"></canvas>
        </div>

    </div>

</div>

<script>
    // --- CHART CONFIGURATION (Mock Data for Visuals) ---

    // Shared Color Palette
    const colors = {
        primary: '#0D6EFD',
        purple: '#6610F2',
        success: '#198754',
        warning: '#ffc107',
        danger: '#dc3545',
        gray: '#6c757d'
    };

    // 1. Revenue Chart
    new Chart(document.getElementById('revenueChart'), {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            datasets: [{
                label: 'Revenue ($)',
                data: [12000, 19000, 3000, 5000, 20000, 30000, 45000, 41000, 38000, 52000, 60000, 75000],
                borderColor: colors.primary,
                backgroundColor: 'rgba(13, 110, 253, 0.1)',
                tension: 0.4,
                fill: true
            }, {
                label: 'Expenses ($)',
                data: [8000, 12000, 2000, 4000, 15000, 20000, 25000, 22000, 21000, 30000, 35000, 40000],
                borderColor: colors.danger,
                borderDash: [5, 5],
                tension: 0.4
            }]
        },
        options: { responsive: true, interaction: { mode: 'index', intersect: false } }
    });

    // 2. Traffic Chart
    new Chart(document.getElementById('trafficChart'), {
        type: 'bar',
        data: {
            labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            datasets: [{
                label: 'Visitors',
                data: [500, 1200, 1400, 1100, 2000, 2500, 2100],
                backgroundColor: colors.purple,
                borderRadius: 4
            }]
        }
    });

    // 3. Device Usage (Doughnut)
    new Chart(document.getElementById('deviceChart'), {
        type: 'doughnut',
        data: {
            labels: ['Desktop', 'Mobile', 'Tablet'],
            datasets: [{
                data: [55, 35, 10],
                backgroundColor: [colors.primary, colors.success, colors.warning]
            }]
        }
    });

    // 4. Sales by Category (Polar Area)
    new Chart(document.getElementById('categoryChart'), {
        type: 'polarArea',
        data: {
            labels: ['Electronics', 'Fashion', 'Home', 'Beauty', 'Sports'],
            datasets: [{
                data: [11, 16, 7, 3, 14],
                backgroundColor: [
                    'rgba(13, 110, 253, 0.7)',
                    'rgba(102, 16, 242, 0.7)',
                    'rgba(25, 135, 84, 0.7)',
                    'rgba(255, 193, 7, 0.7)',
                    'rgba(220, 53, 69, 0.7)'
                ]
            }]
        }
    });

    // 5. User Growth (Line)
    new Chart(document.getElementById('userGrowthChart'), {
        type: 'line',
        data: {
            labels: ['W1', 'W2', 'W3', 'W4'],
            datasets: [{
                label: 'New Users',
                data: [50, 80, 150, 220],
                borderColor: colors.success,
                backgroundColor: 'rgba(25, 135, 84, 0.1)',
                fill: true
            }]
        }
    });

    // 6. Order Status (Horizontal Bar)
    new Chart(document.getElementById('orderStatusChart'), {
        type: 'bar',
        indexAxis: 'y',
        data: {
            labels: ['Delivered', 'Shipped', 'Processing', 'Cancelled'],
            datasets: [{
                label: 'Orders',
                data: [150, 45, 20, 5],
                backgroundColor: [colors.success, colors.primary, colors.warning, colors.danger]
            }]
        }
    });
</script>

<?php
// 2. Include Footer
include 'footer.php';
?>