</div> <!-- End of .container -->

<!-- Admin Footer -->
<footer style="background:#1e293b; color:#94a3b8; padding:20px 0; margin-top: auto; font-size:0.85rem; text-align:center; width: 100%;">
    <div class="container">
        &copy; <?php echo date('Y'); ?> Lumina Admin Panel. All rights reserved.
    </div>
</footer>

<!-- Shared JavaScript -->
<script src="../js/app.js"></script>

</body>
</html>