<?php session_start(); require_once '../db.php'; if($_SESSION['role']!='admin') die; $id=$_GET['id']; $c=$pdo->prepare("SELECT * FROM categories WHERE category_id=?"); $c->execute([$id]); $cat=$c->fetch();
if($_POST){ $pdo->prepare("UPDATE categories SET name=? WHERE category_id=?")->execute([$_POST['name'], $id]); header("Location: categories.php"); }
include 'header.php';
?>
<div class="container" style="margin-top:40px;">

<div style="max-width:500px; margin:0 auto;"><div style="margin-bottom:15px;">
        <a href="categories.php" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left"></i> Back to Categories</a>
    </div><div class="stat-card"><h2>Edit Category</h2><form method="post"><input name="name" value="<?=htmlspecialchars($cat['name'])?>" class="form-control"><button class="btn btn-primary">Update</button></form></div></div></div>
<script src="../js/app.js">
</script>
<script>
const current = location.pathname.split('/').pop();
document.querySelectorAll('.nav-links a').forEach(a => { if(a.getAttribute('href') === current) { a.style.color = '#fff'; a.style.fontWeight = 'bold'; }});
</script>

<?php
// 2. Include Footer
include 'footer.php';
?>