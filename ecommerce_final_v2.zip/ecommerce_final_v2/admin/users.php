<?php session_start(); require_once '../db.php'; if ($_SESSION['role'] !== 'admin') { header("Location: ../login.php"); exit; }
$sql = "SELECT u.*, (SELECT COUNT(*) FROM orders o WHERE o.user_id = u.user_id) as order_count, (SELECT COUNT(*) FROM cart_items ci WHERE ci.user_id = u.user_id) as cart_count FROM users u ORDER BY u.user_id ASC";
$users = $pdo->query($sql)->fetchAll();
include 'header.php';
?>
<div class="container" style="margin-top:40px;">

    <div class="admin-header"><h2>User Management</h2></div>
    <table class="admin-table"><thead><tr><th>ID</th><th>Full Name</th><th>Email</th><th>Role</th><th>Joined</th><th>Orders</th><th>Cart</th><th>Actions</th></tr></thead>
    <tbody><?php foreach($users as $u): ?><tr><td>#<?= $u['user_id'] ?></td><td><b><?= htmlspecialchars($u['full_name']) ?></b></td><td><?= htmlspecialchars($u['email']) ?></td>
    <td><span class="badge <?= $u['role']=='admin'?'badge-admin':'badge-secondary' ?>"><?= $u['role'] ?></span></td><td><?= date('M d, Y', strtotime($u['created_at'])) ?></td><td><?= $u['order_count'] ?></td><td><?= $u['cart_count'] ?></td>
    <td class="admin-actions"><a href="user_details.php?id=<?= $u['user_id'] ?>" class="action-icon view-icon"><i class="fas fa-eye"></i></a><a href="edit_user.php?id=<?= $u['user_id'] ?>" class="action-icon edit-icon"><i class="fas fa-edit"></i></a>
    <?php if($u['user_id'] != $_SESSION['user_id']): ?><a href="#" onclick="confirmDelete('delete_user.php?id=<?= $u['user_id'] ?>')" class="action-icon delete-icon"><i class="fas fa-trash"></i></a><?php endif; ?></td></tr><?php endforeach; ?></tbody></table>
</div>
<script src="../js/app.js"></script>
<script>
    const current = location.pathname.split('/').pop();
    document.querySelectorAll('.nav-links a').forEach(a => { if(a.getAttribute('href') === current) { a.style.color = '#fff'; a.style.fontWeight = 'bold'; }});
</script>
<?php
// 2. Include Footer
include 'footer.php';
?>