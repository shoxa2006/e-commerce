<?php session_start(); require_once '../db.php'; if ($_SESSION['role'] !== 'admin') die; $id=$_GET['id']; $p=$pdo->prepare("SELECT * FROM products WHERE product_id=?"); $p->execute([$id]); $prod=$p->fetch(); $cats=$pdo->query("SELECT * FROM categories")->fetchAll();
if($_POST){ $pdo->prepare("UPDATE products SET name=?, description=?, price=?, category_id=?, image_url=? WHERE product_id=?")->execute([$_POST['name'],$_POST['desc'],$_POST['price'],$_POST['cat'],$_POST['img'],$id]); header("Location: index.php"); }
include 'header.php';
?>
<div class="container" style="margin-top:40px;">

<div style="max-width:600px; margin:0 auto;"><div style="margin-bottom:15px;">
        <a href="products.php" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left"></i> Back to Products</a>
    </div><div class="stat-card"><h2>Edit Product</h2><form method="post"><label>Name</label><input name="name" value="<?=htmlspecialchars($prod['name'])?>" class="form-control"><label>Cat</label><select name="cat" class="form-control"><?php foreach($cats as $c): ?><option value="<?=$c['category_id']?>" <?=$prod['category_id']==$c['category_id']?'selected':''?>><?=$c['name']?></option><?php endforeach; ?></select><label>Price</label><input name="price" value="<?=$prod['price']?>" class="form-control"><label>Img</label><input name="img" value="<?=htmlspecialchars($prod['image_url'])?>" class="form-control"><label>Desc</label><textarea name="desc" class="form-control"><?=$prod['description']?></textarea><button class="btn btn-primary">Save</button></form></div></div>
</div>
<script src="../js/app.js"></script>
<script>
const current = location.pathname.split('/').pop();
document.querySelectorAll('.nav-links a').forEach(a => { if(a.getAttribute('href') === current) { a.style.color = '#fff'; a.style.fontWeight = 'bold'; }});
</script>

<?php
// 2. Include Footer
include 'footer.php';
?>