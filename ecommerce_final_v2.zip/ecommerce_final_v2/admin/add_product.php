<?php session_start(); require_once '../db.php'; if($_SESSION['role']!='admin') die; $cats=$pdo->query("SELECT * FROM categories")->fetchAll(); 
if($_POST){ $pdo->prepare("INSERT INTO products (name, description, price, category_id, image_url) VALUES (?,?,?,?,?)")->execute([$_POST['name'],$_POST['desc'],$_POST['price'],$_POST['cat'],$_POST['img']]); header("Location: index.php"); }
include 'header.php';
?>
<div class="container" style="margin-top:40px;">

<div style="max-width:600px; margin:0 auto;"><div style="margin-bottom:15px;">
        <a href="products.php" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left"></i> Back to Products</a>
    </div><div class="stat-card"><h2>Add Product</h2><form method="post"><label>Name</label><input name="name" class="form-control"><label>Category</label><select name="cat" class="form-control"><?php foreach($cats as $c) echo "<option value='{$c['category_id']}'>{$c['name']}</option>"; ?></select><label>Price</label><input name="price" class="form-control"><label>Img URL</label><input name="img" class="form-control"><label>Desc</label><textarea name="desc" class="form-control"></textarea><button class="btn btn-primary">Add</button></form></div></div>
</div>
<script src="../js/app.js"></script>
<script>
    const current = location.pathname.split('/').pop();
    document.querySelectorAll('.nav-links a').forEach(a => { if(a.getAttribute('href') === current) { a.style.color = '#fff'; a.style.fontWeight = 'bold'; }});
</script>
<?php
// 2. Include Footer
include 'footer.php';
?>