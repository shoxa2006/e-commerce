<?php
session_start();
require_once 'db.php';
include 'header.php';

$uid = $_SESSION['user_id'] ?? 0;
$i = $pdo->prepare("SELECT ci.*, p.name, p.price, p.image_url FROM cart_items ci JOIN products p ON ci.product_id=p.product_id WHERE user_id=?");
$i->execute([$uid]);
$all = $i->fetchAll();
?>

    <div class="container" style="margin-top:40px; margin-bottom:60px;">
        <h2 style="margin-bottom:20px;">Your Cart</h2>

        <?php if(!$all): ?>
            <div style="text-align:center; padding:50px; background:white; border-radius:12px; border:1px solid #dee2e6;">
                <p style="font-size:1.2rem; color:#6c757d;">Your cart is empty.</p>
                <a href="products.php" class="btn btn-primary" style="margin-top:10px;">Start Shopping</a>
            </div>
        <?php else: ?>
            <table class="admin-table">
                <thead>
                <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th style="text-align:right;">Action</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $total = 0;
                foreach($all as $x):
                    $total += $x['price'] * $x['quantity'];
                    ?>
                    <tr>
                        <td style="display:flex; align-items:center; gap:15px;">
                            <img src="<?=$x['image_url']?>" width="60" style="border-radius:6px;">
                            <b><?=$x['name']?></b>
                        </td>
                        <td>$<?=$x['price']?></td>
                        <td><?=$x['quantity']?></td>
                        <td style="text-align:right;">
                            <button onclick="removeFromCart(<?=$x['cart_item_id']?>)" class="btn btn-danger btn-sm">
                                <i class="fas fa-times"></i>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <div style="margin-top:30px; background:white; padding:20px; border-radius:12px; border:1px solid #dee2e6; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:20px;">

                <div style="font-size:1.5rem; font-weight:700;">
                    Total: <span style="color:var(--primary);">$<?= number_format($total, 2) ?></span>
                </div>

                <div style="display:flex; gap:15px;">
                    <a href="products.php" class="btn btn-secondary">Continue Shopping</a>
                    <button onclick="checkout()" class="btn btn-primary">Checkout</button>
                </div>

            </div>
        <?php endif; ?>
    </div>

    <script>

    </script>

<?php include 'footer.php'; ?>