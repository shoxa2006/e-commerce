document.addEventListener('DOMContentLoaded', () => {
    const wrapper = document.querySelector('.slider-wrapper');
    if(!wrapper) return;
    const slides = document.querySelectorAll('.slide');
    const prevBtn = document.querySelector('.prev-slide');
    const nextBtn = document.querySelector('.next-slide');
    let index = 0;
    function showSlide(n) { index = (n + slides.length) % slides.length; wrapper.style.transform = `translateX(-${index * 100}%)`; }
    nextBtn?.addEventListener('click', () => showSlide(index + 1));
    prevBtn?.addEventListener('click', () => showSlide(index - 1));
    setInterval(() => showSlide(index + 1), 5000);
});