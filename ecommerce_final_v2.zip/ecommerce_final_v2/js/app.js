/* =========================================
   1. GLOBAL MODAL SYSTEM (Fixed)
   ========================================= */
const modal = {
    init: () => {
        if (!document.getElementById('globalModal')) return false;
        return true;
    },

    // Standard Message Modal
    show: (title, message, type = 'success', redirectUrl = null) => {
        if(!modal.init()) { alert(message); return; }

        const overlay = document.getElementById('globalModal');
        const box = overlay.querySelector('.modal-box');
        const icon = box.querySelector('.modal-icon i');
        const titleEl = box.querySelector('.modal-title');
        const msgEl = box.querySelector('.modal-msg');

        // Reset
        box.className = 'modal-box';
        box.classList.add(type === 'error' ? 'modal-error' : 'modal-success');

        if(type === 'error') icon.className = 'fas fa-times-circle';
        else icon.className = 'fas fa-check-circle';

        titleEl.textContent = title;
        msgEl.textContent = message;

        // Clean Button Area

        // 1. REMOVE THE HARDCODED "OKAY" BUTTON (Fixes duplicate)
        const defaultBtn = document.getElementById('modalCloseBtn');
        if(defaultBtn) defaultBtn.remove();

        // 2. Remove any previous dynamic buttons
        let btnContainer = box.querySelector('.modal-actions');
        if(btnContainer) btnContainer.remove();

        btnContainer = document.createElement('div');

        btnContainer = document.createElement('div');
        btnContainer.className = 'modal-actions';
        btnContainer.style.marginTop = '20px';
        btnContainer.innerHTML = `<button class="btn btn-primary w-100" id="modalOkBtn">Okay</button>`;
        box.appendChild(btnContainer);

        document.getElementById('modalOkBtn').onclick = () => {
            modal.hide();
            if (redirectUrl) window.location.href = redirectUrl;
        };

        overlay.classList.add('open');
    },

    // NEW: Flexible Confirmation Modal
    // Added 'btnText' and 'btnType' parameters
    confirm: (title, message, onConfirm, btnText = 'Delete', btnType = 'danger') => {
        if(!modal.init()) { if(confirm(message)) onConfirm(); return; }

        const overlay = document.getElementById('globalModal');
        const box = overlay.querySelector('.modal-box');
        const icon = box.querySelector('.modal-icon i');
        const titleEl = box.querySelector('.modal-title');
        const msgEl = box.querySelector('.modal-msg');

        box.className = 'modal-box';
        icon.className = 'fas fa-question-circle';
        icon.style.color = 'var(--primary)';

        titleEl.textContent = title;
        msgEl.textContent = message;

        // Button Logic

        // 1. REMOVE THE HARDCODED "OKAY" BUTTON
        const defaultBtn = document.getElementById('modalCloseBtn');
        if(defaultBtn) defaultBtn.remove();

        // 2. Remove any old button containers
        let btnContainer = box.querySelector('.modal-actions');
        if(btnContainer) btnContainer.remove();

        btnContainer = document.createElement('div');

        btnContainer = document.createElement('div');
        btnContainer.className = 'modal-actions';
        btnContainer.style.marginTop = '20px';
        btnContainer.style.display = 'flex';
        btnContainer.style.gap = '10px';

        // Determine button class (Red for delete, Blue for checkout)
        const btnClass = btnType === 'danger' ? 'btn-danger' : 'btn-primary';

        btnContainer.innerHTML = `
            <button class="btn btn-secondary" style="flex:1;" id="cancelBtn">Cancel</button>
            <button class="btn ${btnClass}" style="flex:1;" id="confirmBtn">${btnText}</button>
        `;
        box.appendChild(btnContainer);

        document.getElementById('cancelBtn').onclick = () => modal.hide();
        document.getElementById('confirmBtn').onclick = () => {
            modal.hide();
            onConfirm();
        };

        overlay.classList.add('open');
    },

    hide: () => {
        const overlay = document.getElementById('globalModal');
        if (overlay) overlay.classList.remove('open');
    }
};

window.addEventListener('click', (e) => {
    if (e.target.id === 'globalModal') modal.hide();
});


/* =========================================
   2. PRODUCT SEARCH (Loading Fix)
   ========================================= */
document.addEventListener('DOMContentLoaded', () => {
    const productsContainer = document.getElementById('productsContainer');
    if (!productsContainer) return;

    const inputs = ['searchInput', 'categoryFilter', 'sortFilter', 'minPrice', 'maxPrice'];

    const fetchProducts = async () => {
        const params = new URLSearchParams();
        inputs.forEach(id => {
            const el = document.getElementById(id);
            if(el && el.value) params.append(el.name || el.id, el.value);
        });

        const urlParams = new URLSearchParams(window.location.search);
        if(!document.getElementById('categoryFilter').value && urlParams.has('category_id')) {
            params.set('category', urlParams.get('category_id'));
        }

        // NO Loading text - visual opacity only
        productsContainer.style.opacity = '0.5';

        try {
            const res = await fetch(`api/search.php?${params.toString()}`);
            if (!res.ok) throw new Error(`API Error`);

            const text = await res.text();
            let products;
            try { products = JSON.parse(text); } catch (err) { console.error("Bad JSON", text); return; }

            // CLEAR OLD CONTENT IMMEDIATELY
            productsContainer.innerHTML = '';

            if(!products || products.length === 0) {
                productsContainer.innerHTML = `<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: #64748b;"><h3>No products found</h3></div>`;
            } else {
                productsContainer.innerHTML = products.map(p => `
                    <div class="product-card">
                        <div class="product-img-wrap"><a href="product.php?id=${p.product_id}"><img src="${p.image_url}" class="product-img" loading="lazy"></a></div>
                        <div class="product-info">
                            <div class="product-cat">${p.category_name || 'General'}</div>
                            <h3 class="product-title"><a href="product.php?id=${p.product_id}">${p.name}</a></h3>
                            <div class="product-bottom"><span class="product-price">$${parseFloat(p.price).toFixed(2)}</span><button class="add-btn-mini" onclick="addToCart(${p.product_id})"><i class="fas fa-plus"></i></button></div>
                        </div>
                    </div>`).join('');
            }
        } catch(e) { console.error(e); } finally { productsContainer.style.opacity = '1'; }
    };

    let timeout;
    const debouncedFetch = () => { clearTimeout(timeout); timeout = setTimeout(fetchProducts, 300); };

    inputs.forEach(id => {
        const el = document.getElementById(id);
        if(el) { el.addEventListener('input', debouncedFetch); el.addEventListener('change', fetchProducts); }
    });
    fetchProducts();
});


/* =========================================
   3. CART ACTIONS (Checkout Fixed)
   ========================================= */
async function addToCart(id) {
    const fd = new FormData();
    fd.append('action', 'add');
    fd.append('product_id', id);
    fd.append('quantity', 1);

    try {
        const res = await fetch('api/cart_actions.php', { method:'POST', body:fd });
        const data = await res.json();
        if(data.success) modal.show('Success', 'Item added to cart!');
        else {
            if(data.message === 'Unauthorized') window.location.href = 'login.php';
            else modal.show('Error', data.message, 'error');
        }
    } catch(e) { modal.show('Error', 'Connection failed', 'error'); }
}

function removeFromCart(id) {
    // Uses standard "Delete" (Red) style
    modal.confirm('Remove Item?', 'Remove this item from your cart?', async () => {
        const fd = new FormData();
        fd.append('action', 'remove');
        fd.append('cart_item_id', id);
        const res = await fetch('api/cart_actions.php', { method:'POST', body:fd });
        const data = await res.json();
        if(data.success) modal.show('Removed', 'Item removed.', 'success', 'cart.php');
        else modal.show('Error', data.message, 'error');
    });
}

function checkout() {
    // FIX: Uses "Pay Now" (Blue) style
    modal.confirm(
        'Checkout',
        'Proceed with order payment?',
        async () => {
            const fd = new FormData();
            fd.append('action', 'checkout');
            const res = await fetch('api/cart_actions.php', { method:'POST', body:fd });
            const data = await res.json();
            if(data.success) modal.show('Order Placed', 'Thank you for your purchase!', 'success', 'index.php');
            else modal.show('Error', data.message, 'error');
        },
        'Pay Now', // Button Text
        'primary'  // Button Color (Blue)
    );
}

function confirmDelete(url) {
    modal.confirm('Delete Item?', 'This cannot be undone.', () => { window.location.href = url; });
}


// --- CUSTOM DROPDOWN LOGIC (FIXED) ---
document.addEventListener('DOMContentLoaded', () => {

    // 1. Setup all custom dropdowns
    document.querySelectorAll('.custom-select-wrapper').forEach(wrapper => {

        const trigger = wrapper.querySelector('.custom-select-trigger');
        const options = wrapper.querySelectorAll('.custom-option');
        const hiddenInput = wrapper.querySelector('input[type="hidden"]');

        // Toggle Open/Close (Logic Fix)
        trigger.addEventListener('click', (e) => {
            e.stopPropagation(); // Stop click from bubbling to window

            // Check if THIS one is already open
            const isCurrentlyOpen = wrapper.classList.contains('open');

            // Close ALL dropdowns first (reset state)
            closeAllDropdowns();

            // If it wasn't open before, open it now
            if (!isCurrentlyOpen) {
                wrapper.classList.add('open');
            }
        });

        // Handle Option Click
        options.forEach(option => {
            option.addEventListener('click', (e) => {
                e.stopPropagation(); // Prevent bubbling

                // Update Visuals
                trigger.textContent = option.textContent;

                // Update Data
                hiddenInput.value = option.getAttribute('data-value');

                // Highlight Selected
                wrapper.querySelectorAll('.custom-option').forEach(o => o.classList.remove('selected'));
                option.classList.add('selected');

                // Close Dropdown
                wrapper.classList.remove('open');

                // Trigger Change for Filters
                hiddenInput.dispatchEvent(new Event('change'));
            });
        });
    });

    // 2. Close dropdowns if clicking anywhere else
    document.addEventListener('click', () => closeAllDropdowns());

    function closeAllDropdowns() {
        document.querySelectorAll('.custom-select-wrapper').forEach(w => w.classList.remove('open'));
    }
});