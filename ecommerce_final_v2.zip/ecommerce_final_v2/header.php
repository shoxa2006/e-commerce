<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/db.php';

// Get the current page name
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lumina | Premium eCommerce</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .nav-links a.active { color: var(--primary); font-weight: 700; }
    </style>
</head>
<body>

<div class="modal-overlay" id="globalModal">
    <div class="modal-box">
        <div class="modal-icon"><i class="fas fa-check-circle"></i></div>
        <h3 class="modal-title">Success</h3>
        <p class="modal-msg">Operation completed successfully.</p>
    </div>
</div>

<nav class="navbar">
    <div class="container nav-flex">
        <a href="index.php" class="brand"><i class="fas fa-bolt"></i> Lumina</a>

        <div class="nav-links">
            <a href="index.php" class="<?= ($current_page == 'index.php') ? 'active' : '' ?>">Home</a>
            <a href="categories.php" class="<?= ($current_page == 'categories.php') ? 'active' : '' ?>">Categories</a>
            <a href="products.php" class="<?= ($current_page == 'products.php' || $current_page == 'product.php') ? 'active' : '' ?>">Shop</a>
            <a href="cart.php" class="<?= ($current_page == 'cart.php') ? 'active' : '' ?>">Cart</a>

            <?php if(isset($_SESSION['user_id'])): ?>
                <?php if($_SESSION['role'] === 'admin'): ?>
                    <a href="admin/index.php" class="badge badge-admin">Admin Panel</a>
                <?php endif; ?>

                <a href="profile.php" class="<?= ($current_page == 'profile.php') ? 'active' : '' ?>" title="My Profile">
                    <i class="fas fa-user-circle"></i> Profile
                </a>

                <a href="logout.php" class="btn btn-secondary btn-sm">Logout</a>

            <?php else: ?>
                <div style="display:flex; gap:10px;">
                    <a href="login.php" class="btn btn-secondary btn-sm">Login</a>
                    <a href="register.php" class="btn btn-primary btn-sm">Register</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</nav>