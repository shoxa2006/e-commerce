<?php
session_start();
require_once 'db.php';
include 'header.php';

// 1. Security Check
if (!isset($_SESSION['user_id'])) {
    echo "<script>window.location.href='login.php';</script>";
    exit;
}

$user_id = $_SESSION['user_id'];
$msg = '';
$msgType = '';

// 2. Handle Profile Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Basic Validation
    if (empty($name) || empty($email)) {
        $msg = "Name and Email are required.";
        $msgType = "error";
    } else {
        // Update Logic
        if (!empty($password)) {
            // Update with password
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET full_name = ?, email = ?, password_hash = ? WHERE user_id = ?");
            $success = $stmt->execute([$name, $email, $hash, $user_id]);
        } else {
            // Update info only
            $stmt = $pdo->prepare("UPDATE users SET full_name = ?, email = ? WHERE user_id = ?");
            $success = $stmt->execute([$name, $email, $user_id]);
        }

        if ($success) {
            $msg = "Profile updated successfully!";
            $msgType = "success";
            $_SESSION['name'] = $name; // Update session name
        } else {
            $msg = "Update failed. Email might be taken.";
            $msgType = "error";
        }
    }
}

// 3. Fetch User Data
$userStmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
$userStmt->execute([$user_id]);
$user = $userStmt->fetch();

// 4. Fetch Order History
$orderStmt = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC");
$orderStmt->execute([$user_id]);
$orders = $orderStmt->fetchAll();
?>

<?php if($msg): ?>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            modal.show('<?= $msgType === "success" ? "Success" : "Error" ?>', '<?= $msg ?>', '<?= $msgType ?>');
        });
    </script>
<?php endif; ?>

    <div class="container" style="margin-top: 40px; margin-bottom: 80px;">

        <div style="margin-bottom: 30px;">
            <h1 style="font-size: 2rem; font-weight: 800; margin-bottom: 5px;">My Account</h1>
            <p style="color: var(--text-muted);">Manage your details and view your orders.</p>
        </div>

        <div class="layout-grid">

            <div style="background: white; padding: 30px; border-radius: 16px; border: 1px solid var(--border);">
                <h3 style="margin-bottom: 20px; font-size: 1.1rem; border-bottom: 1px solid var(--border); padding-bottom: 10px;">
                    Profile Details
                </h3>

                <form method="POST">
                    <label style="font-weight: 600; font-size: 0.9rem; margin-bottom: 5px; display: block;">Full Name</label>
                    <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($user['full_name']) ?>" required>

                    <label style="font-weight: 600; font-size: 0.9rem; margin-bottom: 5px; display: block;">Email Address</label>
                    <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" required>

                    <label style="font-weight: 600; font-size: 0.9rem; margin-bottom: 5px; display: block;">New Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Leave blank to keep current">
                    <p style="font-size: 0.8rem; color: var(--text-muted); margin-top: -10px; margin-bottom: 20px;">
                        Only enter a value if you want to change it.
                    </p>

                    <button type="submit" class="btn btn-primary w-100">Save Changes</button>
                </form>
            </div>

            <div>
                <div style="background: white; border-radius: 16px; border: 1px solid var(--border); overflow: hidden;">
                    <div style="padding: 20px; background: #f8f9fa; border-bottom: 1px solid var(--border); font-weight: 700;">
                        Order History
                    </div>

                    <?php if (empty($orders)): ?>
                        <div style="padding: 40px; text-align: center; color: var(--text-muted);">
                            <i class="fas fa-shopping-bag" style="font-size: 2rem; margin-bottom: 10px; opacity: 0.5;"></i>
                            <p>No orders placed yet.</p>
                            <a href="products.php" class="btn btn-sm btn-secondary" style="margin-top: 10px;">Start Shopping</a>
                        </div>
                    <?php else: ?>
                        <table class="admin-table" style="box-shadow: none; border: none; margin: 0;">
                            <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Date</th>
                                <th>Total</th>
                                <th>Status</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($orders as $o): ?>
                                <tr>
                                    <td style="font-weight: 600; color: var(--primary);">#<?= $o['order_id'] ?></td>
                                    <td style="font-size: 0.9rem;"><?= date('M d, Y', strtotime($o['created_at'])) ?></td>
                                    <td style="font-weight: 700;">$<?= number_format($o['total'], 2) ?></td>
                                    <td>
                                        <span class="badge badge-secondary" style="background: #dcfce7; color: #16a34a; border:none;">Completed</span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>

<?php include 'footer.php'; ?>