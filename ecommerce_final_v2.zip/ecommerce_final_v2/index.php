<?php
require_once 'db.php';
include 'header.php';

// 1. Fetch Featured Categories (Top 4)
$catStmt = $pdo->query("SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id = c.category_id) as p_count FROM categories c LIMIT 4");
$cats = $catStmt->fetchAll();

// 2. Fetch Trending Products (Random 8 items)
$prodStmt = $pdo->query("SELECT p.*, c.name as cat_name FROM products p LEFT JOIN categories c ON p.category_id = c.category_id ORDER BY RANDOM() LIMIT 8");
$featured = $prodStmt->fetchAll();
?>

    <section style="background: var(--bg-card); padding: 80px 0; border-bottom: 1px solid var(--border); position: relative; overflow: hidden;">
        <div class="hero-blob-animated"></div>
        <div class="container" style="position: relative; z-index: 1; text-align: center;">
            <span class="badge" style="background: #e0f2fe; color: #0284c7; font-size: 0.9rem; margin-bottom: 20px; display: inline-block;">New Collection 2025</span>
            <h1 style="font-size: 4rem; font-weight: 800; line-height: 1.1; margin-bottom: 20px; letter-spacing: -2px;">
                Next Gen <span style="background: var(--accent-grad); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Technology</span>
            </h1>
            <p style="font-size: 1.25rem; color: var(--text-muted); max-width: 600px; margin: 0 auto 30px;">
                Upgrade your lifestyle with our curated selection of premium electronics and minimalist fashion staples.
            </p>
            <div style="display: flex; gap: 15px; justify-content: center;">
                <a href="products.php" class="btn btn-primary" style="padding: 15px 40px; font-size: 1.1rem; border-radius: 50px;">Shop Now</a>
                <a href="#trending" class="btn btn-secondary" style="padding: 15px 40px; font-size: 1.1rem; border-radius: 50px;">View Trending</a>
            </div>
        </div>
    </section>

    <div style="background: white; border-bottom: 1px solid var(--border);">
        <div class="container">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 30px; padding: 50px 0;">

                <div style="display: flex; align-items: center; gap: 20px;">
                    <div class="feature-icon-box grad-blue">
                        <i class="fas fa-truck"></i>
                    </div>
                    <div>
                        <h4 style="font-size: 1.1rem; margin: 0; font-weight:700;">Free Shipping</h4>
                        <span style="font-size: 0.9rem; color: var(--text-muted);">On orders over $100</span>
                    </div>
                </div>

                <div style="display: flex; align-items: center; gap: 20px;">
                    <div class="feature-icon-box grad-green">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <div>
                        <h4 style="font-size: 1.1rem; margin: 0; font-weight:700;">Secure Payment</h4>
                        <span style="font-size: 0.9rem; color: var(--text-muted);">100% protected</span>
                    </div>
                </div>

                <div style="display: flex; align-items: center; gap: 20px;">
                    <div class="feature-icon-box grad-purple">
                        <i class="fas fa-undo"></i>
                    </div>
                    <div>
                        <h4 style="font-size: 1.1rem; margin: 0; font-weight:700;">Easy Returns</h4>
                        <span style="font-size: 0.9rem; color: var(--text-muted);">30 day guarantee</span>
                    </div>
                </div>

                <div style="display: flex; align-items: center; gap: 20px;">
                    <div class="feature-icon-box grad-orange">
                        <i class="fas fa-headset"></i>
                    </div>
                    <div>
                        <h4 style="font-size: 1.1rem; margin: 0; font-weight:700;">24/7 Support</h4>
                        <span style="font-size: 0.9rem; color: var(--text-muted);">Dedicated team</span>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="container">

        <div class="slider-container" style="margin-top: 60px;">
            <div class="slider-wrapper">
                <div class="slide" style="background-image: linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.4)), url('https://images.unsplash.com/photo-1550009158-9ebf69173e03?w=1200&q=80');">
                    <div class="slide-content" style="color: white; text-align: left;">
                        <span class="badge badge-primary" style="margin-bottom: 10px;">Featured</span>
                        <h2 style="font-size: 2.5rem; font-weight: 800; margin-bottom: 10px;">Premium Audio</h2>
                        <p style="margin-bottom: 20px; font-size: 1.1rem;">Immerse yourself in crystal clear sound with our latest collection.</p>
                        <a href="products.php?category_id=1" class="btn btn-primary">Explore Audio</a>
                    </div>
                </div>
                <div class="slide" style="background-image: linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.4)), url('https://images.unsplash.com/photo-1483985988355-763728e1935b?w=1200&q=80');">
                    <div class="slide-content" style="color: white; text-align: left;">
                        <span class="badge badge-primary" style="margin-bottom: 10px;">New Season</span>
                        <h2 style="font-size: 2.5rem; font-weight: 800; margin-bottom: 10px;">Minimalist Fashion</h2>
                        <p style="margin-bottom: 20px; font-size: 1.1rem;">Sustainable staples for the modern wardrobe.</p>
                        <a href="products.php?category_id=2" class="btn btn-primary">Shop Fashion</a>
                    </div>
                </div>
            </div>
            <div class="slider-nav">
                <button class="slider-btn prev-slide"><i class="fas fa-chevron-left"></i></button>
                <button class="slider-btn next-slide"><i class="fas fa-chevron-right"></i></button>
            </div>
        </div>

        <div style="display: flex; justify-content: space-between; align-items: end; margin: 80px 0 30px;">
            <div>
                <h2 class="section-title" style="text-align: left; margin: 0;">Browse by Category</h2>
                <p style="color: var(--text-muted); margin-top: 5px;">Find exactly what you need.</p>
            </div>
            <a href="categories.php" style="color: var(--primary); font-weight: 600;">View All <i class="fas fa-arrow-right"></i></a>
        </div>

        <div class="cat-grid">
            <?php foreach($cats as $c): ?>
                <div class="cat-card" onclick="location.href='products.php?category_id=<?= $c['category_id'] ?>'">
                    <div style="font-size: 2.5rem; color: var(--primary); margin-bottom: 15px; opacity: 0.8;">
                        <?php if(stripos($c['name'], 'electr') !== false): ?><i class="fas fa-laptop"></i>
                        <?php elseif(stripos($c['name'], 'fashion') !== false): ?><i class="fas fa-tshirt"></i>
                        <?php elseif(stripos($c['name'], 'home') !== false): ?><i class="fas fa-couch"></i>
                        <?php else: ?><i class="fas fa-layer-group"></i><?php endif; ?>
                    </div>
                    <div class="cat-name" style="font-size: 1.1rem; font-weight: 700;"><?= htmlspecialchars($c['name']) ?></div>
                    <div class="cat-count"><?= $c['p_count'] ?> products</div>
                </div>
            <?php endforeach; ?>
        </div>

        <div id="trending" style="margin-top: 80px; margin-bottom: 30px;">
            <h2 class="section-title" style="margin: 0;">Trending Now</h2>
            <p class="text-center" style="color: var(--text-muted);">Top picks for this week.</p>
        </div>

        <div class="products-grid" style="margin-bottom: 100px;">
            <?php foreach($featured as $p): ?>
                <div class="product-card">
                    <div class="product-img-wrap">
                        <a href="product.php?id=<?= $p['product_id'] ?>">
                            <img src="<?= $p['image_url'] ?>" class="product-img" alt="<?= htmlspecialchars($p['name']) ?>">
                        </a>
                        <span style="position: absolute; top: 10px; left: 10px; background: white; padding: 4px 10px; border-radius: 4px; font-size: 0.75rem; font-weight: 700; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">NEW</span>
                    </div>
                    <div class="product-info">
                        <div class="product-cat"><?= htmlspecialchars($p['cat_name'] ?? 'General') ?></div>
                        <h3 class="product-title">
                            <a href="product.php?id=<?= $p['product_id'] ?>"><?= htmlspecialchars($p['name']) ?></a>
                        </h3>
                        <div class="product-bottom">
                            <span class="product-price">$<?= number_format($p['price'], 2) ?></span>
                            <button class="add-btn-mini btn-icon" onclick="addToCart(<?= $p['product_id'] ?>)" title="Add to Cart">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

    </div>

    <div style="background: #111827; color: white; padding: 80px 0; text-align: center;">
        <div class="container">
            <h2 style="font-size: 2.5rem; margin-bottom: 15px;">Join the Lumina Club</h2>
            <p style="color: #9ca3af; margin-bottom: 30px; max-width: 500px; margin-left: auto; margin-right: auto;">
                Subscribe to receive updates, access to exclusive deals, and more.
            </p>
            <div style="display: flex; gap: 10px; justify-content: center; max-width: 400px; margin: 0 auto;">
                <input type="email" placeholder="Enter your email" style="padding: 12px 20px; border-radius: 50px; border: none; flex-grow: 1; outline: none;">
                <button class="btn btn-primary" style="border-radius: 50px; padding: 12px 30px;">Subscribe</button>
            </div>
        </div>
    </div>

<?php include 'footer.php'; ?>