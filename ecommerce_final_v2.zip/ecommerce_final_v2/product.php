<?php
require_once 'db.php';
include 'header.php';

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT p.*, c.name as cat_name FROM products p LEFT JOIN categories c ON p.category_id = c.category_id WHERE p.product_id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch();

if(!$product) {
    echo "<div class='container' style='padding:50px;'><h2>Product not found</h2><a href='products.php' class='btn btn-secondary'>Back to Shop</a></div>";
} else {
    ?>

    <div class="container" style="margin-top:40px; margin-bottom:60px;">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap:50px; align-items: start;">

            <div style="background:white; padding:20px; border-radius:12px; border:1px solid #dee2e6;">
                <img src="<?= $product['image_url'] ?>" style="width:100%; border-radius:8px; object-fit:cover;">
            </div>

            <div style="display:flex; flex-direction:column; height:100%;">
                <span class="badge badge-secondary" style="align-self:start; margin-bottom:10px;"><?= htmlspecialchars($product['cat_name']) ?></span>

                <h1 style="font-size:2.5rem; line-height:1.2; margin-bottom:15px;"><?= htmlspecialchars($product['name']) ?></h1>

                <div style="font-size:2rem; font-weight:700; color:var(--primary); margin-bottom:20px;">
                    $<?= number_format($product['price'], 2) ?>
                </div>

                <p style="color:#666; font-size:1.1rem; margin-bottom:30px; line-height:1.7; flex-grow:1;">
                    <?= nl2br(htmlspecialchars($product['description'])) ?>
                </p>

                <div style="border-top:1px solid #dee2e6; padding-top:20px;">
                    <button class="btn btn-primary w-100" style="padding:15px; font-size:1.1rem;" onclick="addToCart(<?= $product['product_id'] ?>)">
                        <i class="fas fa-shopping-cart"></i> Add to Cart
                    </button>
                </div>
            </div>
        </div>

        <div style="margin-top: 50px; padding-top: 20px; border-top: 1px solid #eee;">
            <a href="products.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Shop
            </a>
        </div>
    </div>

<?php } include 'footer.php'; ?>