<?php
require_once 'db.php';
include 'header.php';

// Fetch all categories with product counts
$sql = "SELECT c.*, 
        (SELECT COUNT(*) FROM products p WHERE p.category_id = c.category_id) as p_count 
        FROM categories c 
        ORDER BY name";
$categories = $pdo->query($sql)->fetchAll();

// Helper function to pick icons based on name
function getCategoryIcon($name) {
    $n = strtolower($name);
    if (strpos($n, 'elec') !== false) return 'fa-laptop';     // Electronics
    if (strpos($n, 'phone') !== false) return 'fa-mobile-alt';
    if (strpos($n, 'fash') !== false) return 'fa-tshirt';     // Fashion
    if (strpos($n, 'cloth') !== false) return 'fa-tshirt';
    if (strpos($n, 'home') !== false) return 'fa-couch';      // Home
    if (strpos($n, 'livin') !== false) return 'fa-couch';
    if (strpos($n, 'acc') !== false) return 'fa-glasses';     // Accessories
    if (strpos($n, 'shoe') !== false) return 'fa-shoe-prints';
    if (strpos($n, 'sport') !== false) return 'fa-running';
    return 'fa-layer-group'; // Default fallback
}
?>

    <div style="background: white; border-bottom: 1px solid var(--border); padding: 40px 0;">
        <div class="container">
            <h1 style="font-size: 2rem; margin: 0; font-weight: 800;">All Categories</h1>
            <p style="color: var(--text-muted); margin: 5px 0 0; font-size: 1rem;">
                Explore our wide range of premium collections.
            </p>
        </div>
    </div>

    <div class="container" style="margin-top: 60px; margin-bottom: 100px;">

        <?php if (empty($categories)): ?>
            <div style="text-align: center; padding: 60px; background: white; border-radius: 12px; border: 1px solid var(--border);">
                <i class="fas fa-box-open" style="font-size: 3rem; color: var(--text-muted); margin-bottom: 20px;"></i>
                <h3>No categories found</h3>
                <p style="color: var(--text-muted);">Check back later for updates.</p>
            </div>
        <?php else: ?>

            <div class="cat-grid">
                <?php foreach($categories as $c): ?>
                    <div class="cat-card" onclick="location.href='products.php?category_id=<?= $c['category_id'] ?>'">
                        <i class="fas <?= getCategoryIcon($c['name']) ?>"></i>

                        <div class="cat-name"><?= htmlspecialchars($c['name']) ?></div>
                        <div class="cat-count"><?= $c['p_count'] ?> products</div>

                        <div style="margin-top: 15px; font-size: 0.9rem; color: var(--primary); font-weight: 600;">
                            Browse Collection <i class="fas fa-arrow-right" style="font-size: 0.8rem; margin-left: 5px;"></i>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

        <?php endif; ?>

    </div>

<?php include 'footer.php'; ?>