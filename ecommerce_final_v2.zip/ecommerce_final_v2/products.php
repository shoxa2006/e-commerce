<?php
require_once 'db.php';
include 'header.php';

// Fetch categories for sidebar
$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();
?>

    <div style="background: white; border-bottom: 1px solid var(--border); padding: 30px 0;">
        <div class="container">
            <h1 style="font-size: 1.8rem; margin: 0;">Shop Collection</h1>
            <p style="color: var(--text-muted); margin: 5px 0 0; font-size: 0.95rem;">
                Browse our premium selection of electronics and fashion.
            </p>
        </div>
    </div>

    <div class="container" style="margin-top: 40px; margin-bottom: 80px;">
        <div class="layout-grid">

            <aside class="filters-sidebar">
                <div class="filter-group">
                    <h3>Search</h3>
                    <div style="position: relative;">
                        <input type="text" id="searchInput" name="q" class="form-control" placeholder="Type to search..." style="padding-left: 35px;">
                        <i class="fas fa-search" style="position: absolute; left: 12px; top: 14px; color: #94a3b8;"></i>
                    </div>
                </div>

                <div class="filter-group">
                    <h3>Category</h3>
                    <div class="custom-select-wrapper" id="catWrapper">
                        <input type="hidden" id="categoryFilter" name="category" value="">

                        <div class="custom-select-trigger">All Categories</div>

                        <div class="custom-options">
                            <div class="custom-option selected" data-value="">All Categories</div>
                            <?php foreach($categories as $c): ?>
                                <div class="custom-option" data-value="<?= $c['category_id'] ?>">
                                    <?= htmlspecialchars($c['name']) ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <div class="filter-group">
                    <h3>Price Range</h3>
                    <div style="display:flex; gap:10px;">
                        <input type="number" id="minPrice" name="min" class="form-control" placeholder="Min $">
                        <input type="number" id="maxPrice" name="max" class="form-control" placeholder="Max $">
                    </div>
                </div>

                <div class="filter-group">
                    <h3>Sort By</h3>

                    <div class="custom-select-wrapper" id="sortWrapper">
                        <input type="hidden" id="sortFilter" name="sort" value="newest">

                        <div class="custom-select-trigger">Newest Arrivals</div>

                        <div class="custom-options">
                            <div class="custom-option selected" data-value="newest">Newest Arrivals</div>
                            <div class="custom-option" data-value="oldest">Oldest Items</div>
                            <div class="custom-option" data-value="price_asc">Price: Lowest First</div>
                            <div class="custom-option" data-value="price_desc">Price: Highest First</div>
                        </div>
                    </div>
                </div>

                <button class="btn btn-secondary w-100" onclick="window.location.href='products.php'">Reset Filters</button>
            </aside>

            <div style="width: 100%;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 1px solid var(--border);">
                <span style="font-size: 0.9rem; color: var(--text-muted); font-weight: 500;">
                    Showing results
                </span>

                    <div class="view-btn-group">
                        <button class="view-btn active" onclick="switchView('view-grid-3', this)" title="Classic Grid">
                            <i class="fas fa-th-large"></i>
                        </button>
                        <button class="view-btn" onclick="switchView('view-grid-4', this)" title="Dense Grid">
                            <i class="fas fa-th"></i>
                        </button>
                        <button class="view-btn" onclick="switchView('view-list', this)" title="List View">
                            <i class="fas fa-list"></i>
                        </button>
                    </div>
                </div>

                <main id="productsContainer" class="products-grid view-grid-3">
                </main>
            </div>
        </div>
    </div>

    <script>
        function switchView(viewClass, btn) {
            const container = document.getElementById('productsContainer');
            const buttons = document.querySelectorAll('.view-btn');
            container.classList.remove('view-grid-3', 'view-grid-4', 'view-list');
            container.classList.add(viewClass);
            buttons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            localStorage.setItem('preferredView', viewClass);
        }

        document.addEventListener('DOMContentLoaded', () => {
            const savedView = localStorage.getItem('preferredView');
            if(savedView) {
                const btnMap = { 'view-grid-3': 0, 'view-grid-4': 1, 'view-list': 2 };
                const buttons = document.querySelectorAll('.view-btn');
                if(buttons[btnMap[savedView]]) {
                    switchView(savedView, buttons[btnMap[savedView]]);
                }
            }
        });
    </script>

<?php include 'footer.php'; ?>